<br><br>

<p  style="text-align:center;">You know to write the basic alphabet with ten fingers? How about a little game?</p>

<p  style="text-align:center; font-size: 24px;"><button title="bigger"><a href="typinggame/" target="_blank" style="text-decoration: none; color: inherit;"><span style="font-size: 18px">Speed typing game</a></button>

